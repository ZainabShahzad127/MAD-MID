// components/ProductCard.js
import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Alert } from 'react-native';

export default function ProductCard({ item, onView }) {
  return (
    <View style={styles.card}>
      <Image
        source={ item.imageLocal ? item.imageLocal : { uri: item.image } }
        style={styles.image}
        resizeMode="cover"
      />
      <Text style={styles.name}>{item.name}</Text>
      <Text style={styles.price}>Rs {item.price}</Text>

      <View style={styles.row}>
        <TouchableOpacity style={styles.viewBtn} onPress={() => onView(item)}>
          <Text style={styles.viewText}>View</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.addBtn} onPress={() => Alert.alert('Cart', `${item.name} added to cart (UI only).`)}>
          <Text style={styles.addText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 10,
    margin: 8,
    width: '46%',
    // soft shadow (Android/iOS)
    elevation: 3,
  },
  image: { width: '100%', height: 120, borderRadius: 8 },
  name: { marginTop: 8, fontWeight: '600' },
  price: { marginTop: 4, color: '#FF6B6B', fontWeight: '700' },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
  viewBtn: { padding: 8, borderRadius: 8, backgroundColor: '#E6E6FA' },
  addBtn: { padding: 8, borderRadius: 8, backgroundColor: '#20B2AA' },
  viewText: { fontWeight: '600' },
  addText: { color: 'white', fontWeight: '700' },
});