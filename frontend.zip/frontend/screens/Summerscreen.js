import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function SummerScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Summer Collection</Text>
      <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('Pret')}>
        <Text style={styles.btnText}>Pret</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('Unstitched')}>
        <Text style={styles.btnText}>Unstitched</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20 },
  btn: { backgroundColor: '#333', padding: 15, marginVertical: 10, borderRadius: 8, width: 200 },
  btnText: { color: '#fff', textAlign: 'center', fontSize: 16 },
  
});
