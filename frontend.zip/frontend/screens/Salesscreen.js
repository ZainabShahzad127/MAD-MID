import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

export default function SaleScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sale Items</Text>
      <View style={styles.card}>
        <Image source={require('../../assets/Lawn.png')} style={styles.image} />
        <Text style={styles.name}>Summer Lawn 30% Off</Text>
        <TouchableOpacity style={styles.cartBtn}>
          <Text style={styles.cartText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', padding: 20 },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20 },
  card: { alignItems: 'center', marginVertical: 10 },
  image: { width: 150, height: 150, borderRadius: 10 },
  name: { marginTop: 10, fontSize: 18 },
  cartBtn: { backgroundColor: '#333', marginTop: 8, padding: 10, borderRadius: 5 },
  cartText: { color: '#fff' },
  
});
