import React from 'react';
import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';

export default function HomeScreen({ navigation }) {
  const categories = [
    { name: 'Winter', image: require('../../assets/winter.png') },
    { name: 'Summer', image: require('../../assets/Summercollection.png') },
    { name: 'Perfumes', image: require('../../assets/perfumecollection.png') },
    { name: 'Sale', image: require('../../assets/sale5.png') },
  ];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Welcome to GlamNest</Text>
      {categories.map((item, index) => (
        <TouchableOpacity
          key={index}
          style={styles.card}
          onPress={() => navigation.navigate(item.name)}>
          <Image source={item.image} style={styles.image} />
          <Text style={styles.text}>{item.name} Collection</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, alignItems: 'center' },
  title: { fontSize: 24, fontWeight: 'bold', marginVertical: 10 },
  card: { marginVertical: 10, alignItems: 'center' },
  image: { width: 250, height: 150, borderRadius: 10 },
  text: { marginTop: 8, fontSize: 18, fontWeight: '600' },

  container: { 
  flexGrow: 1,         
  padding: 20, 
  alignItems: 'center',
  backgroundColor: '#e0c9e9ff', 
},
title: { 
  fontSize: 24, 
  fontWeight: 'bold', 
  marginVertical: 10,
  color: '#3709a3ff', // 💡
},


})

