import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

export default function WomenPerfumeScreen() {
  const products = [
    { id: 1, name: 'Rose Mist', image: require('../../assets/purfume2.png') },
    { id: 2, name: 'Jasmine Bloom', image: require('../../assets/perfume1.png') },
    { id: 3, name: 'Amber Grace', image: require('../../assets/purfume.png') },
  ];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Women Perfume Collection</Text>

      {products.map((item) => (
        <View key={item.id} style={styles.card}>
          <Image source={item.image} style={styles.image} />
          <Text style={styles.name}>{item.name}</Text>
          <TouchableOpacity style={styles.cartBtn}>
            <Text style={styles.cartText}>Add to Cart</Text>
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, alignItems: 'center' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    elevation: 3,
    marginVertical: 10,
    alignItems: 'center',
    padding: 10,
    width: 260,
  },
  image: { width: 180, height: 180, borderRadius: 10 },
  name: { fontSize: 18, fontWeight: '600', marginTop: 10 },
  cartBtn: {
    backgroundColor: '#333',
    padding: 10,
    marginTop: 8,
    borderRadius: 5,
    width: 130,
  },
  cartText: { color: '#fff', textAlign: 'center', fontWeight: '500' },
  
});